import numpy as np
from statistic import Statistic