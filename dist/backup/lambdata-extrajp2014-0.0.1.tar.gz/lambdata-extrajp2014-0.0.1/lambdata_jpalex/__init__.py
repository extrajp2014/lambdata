"""
lambdata - a collection of Data Science helper functions.
"""

import pandas as pd
import numpy as np

ONES = pd.DataFrame(np.ones(10))
ZEROS = pd.DataFrame(np.zeros(50))